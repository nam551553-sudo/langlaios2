package beatdz;

import java.util.Arrays;

/** Installs bundled equipment rigs when the server's custom-frame packet is absent. */
final class NewSevenEquipment {
    private NewSevenEquipment() {}

    static void ensure(int appearance) {
        WebAssets.prefetchAppearance(appearance);
        boolean fox = appearance >= 401 && appearance <= 403;
        if (!fox && (appearance < 500 || appearance > 542) && (appearance < 300 || appearance > 308)) return;
        DataCenter data = DataCenter.gI();
        if (data.H == null || data.G == null || data.F == null) return;
        int expected = fox ? (appearance == 401 ? 28300 : 29750 + (appearance - 402) * 10) : appearance >= 500 ? TopupGripAnchors.BASES[appearance-500] : -1;
        if (appearance < data.H.length && data.H[appearance] != null) {
            LangLa_js existing = data.H[appearance];
            if (existing.a != null && existing.a.length > 0 && existing.a[0] != null && existing.a[0].length > 0) {
                int group = existing.a[0][0];
                if (group >= 0 && group < data.G.length && data.G[group] != null && data.G[group].a != null && data.G[group].a.length > 0) {
                    int index = data.G[group].a[0];
                    if (index >= 0 && index < data.F.length && data.F[index] != null) {
                        LangLa_ju[] frames = data.F[index].d;
                        if (frames != null && frames.length >= 33 && frames[0] != null
                                && (expected == -1 || (frames[0].a >= expected
                                && frames[0].a < expected + (fox ? 9 : TopupCostumes.sourceCount(appearance))))) return;
                    }
                }
            }
        }

        LangLa_jr part = new LangLa_jr();
        if (fox) {
            part.d = new LangLa_ju[33];
            for (int pose = 0; pose < part.d.length; pose++) {
                LangLa_ju frame = new LangLa_ju((short) expected);
                frame.width = (short) (appearance == 401 ? 80 : 96);
                frame.height = (short) (appearance == 401 ? 40 : 48);
                float[] hand = TopupWeaponRig.nativeGrip(pose);
                frame.d = (short) Math.round(hand[0] + frame.width * (appearance == 401 ? .16666667f : 0f));
                frame.e = (byte) Math.round(hand[1] + frame.height * (appearance == 401 ? .70f : .50f));
                frame.c = 3;
                part.d[pose] = frame;
            }
        } else if (appearance >= 500) {
            int base = expected;
            LangLa_ju[] source = new LangLa_ju[TopupCostumes.sourceCount(appearance)];
            for (int frame = 0; frame < source.length; frame++) {
                source[frame] = new LangLa_ju((short) (base + frame));
                source[frame].width = 80;
                source[frame].height = 80;
            }
            TopupCostumes.prepareNativePart(part, source, TopupCostumes.nativeReference());
        } else {
            java.util.List<int[]> rows = new java.util.ArrayList<int[]>();
            try {
                for (String line : Utlis.internal("resource/catalog/custom-frames.csv").readString("UTF-8").split("\\n")) {
                    String[] values=line.trim().split(",");
                    if (values.length!=8 || Integer.parseInt(values[0])!=appearance) continue;
                    int[] row=new int[8]; for(int i=0;i<8;i++) row[i]=Integer.parseInt(values[i]);
                    if(Utlis.internal("resource/catalog/zoom4/char/"+row[2]+".png").exists()
                            || Utlis.internal("resource/catalog/zoom1/char/"+row[2]+".png").exists()) rows.add(row);
                }
            } catch(Exception e) { Utlis.writeLog("Recovered rig: "+e); }
            if(rows.isEmpty()) return;
            part.b=99; part.d=new LangLa_ju[1024];
            for(int pose=0;pose<1024;pose++) {
                int action=pose>=60?5:pose>=40?4:pose>=30?3:pose>=20?2:pose>=10?1:0;
                java.util.List<int[]> valid=new java.util.ArrayList<int[]>();
                for(int[] row:rows) if(row[5]==action) valid.add(row);
                if(valid.isEmpty()) for(int[] row:rows) if(row[5]==0) valid.add(row);
                if(valid.isEmpty()) valid=rows;
                int[] row=valid.get(pose%valid.size());
                LangLa_ju frame=new LangLa_ju((short)row[2]); frame.c=50; frame.d=(short)row[3]; frame.e=(byte)row[4]; frame.width=(short)row[6]; frame.height=(short)row[7]; part.d[pose]=frame;
            }
        }

        int group = data.G.length;
        int index = data.F.length;
        data.F = Arrays.copyOf(data.F, index + 1);
        part.a = index;
        data.F[index] = part;
        data.G = Arrays.copyOf(data.G, group + 1);
        data.G[group] = new LangLa_jt();
        data.G[group].a = new short[]{(short) index};
        data.H = Arrays.copyOf(data.H, Math.max(data.H.length, appearance + 1));
        LangLa_js rig = new LangLa_js();
        rig.a = new short[3][128];
        for (short[] variants : rig.a) Arrays.fill(variants, (short) group);
        data.H[appearance] = rig;
    }
}
